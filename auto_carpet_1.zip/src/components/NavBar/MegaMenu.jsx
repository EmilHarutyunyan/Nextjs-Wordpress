import React from 'react'

const MegaMenu = ({menu}) => {
  return (
    <div style={{display:'none'}}>MegaMenu</div>
  )
}

export default MegaMenu